package com.example.healthiest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
